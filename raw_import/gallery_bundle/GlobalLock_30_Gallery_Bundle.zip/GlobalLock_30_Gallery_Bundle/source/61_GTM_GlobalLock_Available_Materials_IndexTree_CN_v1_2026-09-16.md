# GlobalLockSummary / Global Lock 公益网站：可用资料 Index Tree

日期：2026-09-16  
版本：v1  
用途：给交接 Agent 一个“当前 workspace 有什么资料、每份资料做什么、先读什么、哪些不能当作事实”的导航。

---

## 0. 先读这 8 个文件

新 Agent 不需要一开始通读整个 workspace，建议按下面顺序：

1. `60_GTM_Global_Lock_PublicGood_Website_Plan_And_NewAgent_Handoff_CN_v1_2026-09-16.md`
   - 公益网站总体计划、信息架构、隐私、版权、AI、导流、MVP。

2. `60_GTM_NewAgent_Prompt_Global_Lock_PublicGood_Website_CN_v1_2026-09-16.md`
   - 可复制给新 Agent 的执行 prompt。

3. `60_GTM_Global_Lock_Knowledge_Graph_Schema_v1_2026-09-16.json`
   - lock_family、region、profile、input、output、field、adapter、photo、case、source、test、claim 的图谱结构。

4. `60_GTM_Global_Lock_PublicGood_Website_Source_Index_v1_2026-09-16.csv`
   - 机器可读资料索引。

5. `59_GTM_全球锁型全景图_工程适配版_v1_2026-09-16.html`
   - 全球大分类、区域分类、adaptor 思路和照片区域图墙。

6. `57_GTM_30类候选锁安装图_中文汇总_v1_2026-09-16.html`
   - 30 候选样本的安装示意 + 实物案例参考。

7. `58_GTM_全球缺口锁型实物照片图谱_中文汇总_v1_2026-09-16.html`
   - 当前缺口锁族的实物照片、安装环境和工程说明。

8. `60_GTM_GlobalLock_NewAgent_Handoff_Response_CN_v1_2026-09-16.md`
   - 对上一会话提出的 5 个问题和 6 项交接物料的诚实回答。

---

## 1. 当前目录总览

```text
/home/user/
├── exp1/                                      主工作区
│   ├── 00_EXP1-DRIVE_*                        Drive / workspace source-of-truth
│   ├── 38_GTM_*                               竞品与 retrofit 背景
│   ├── 39_GTM_*                               视频证据、参数缺口、抽帧
│   ├── 40_GTM_*                               工程目标参数、Claim Ladder
│   ├── 41_GTM_*                               外观 / 工程设计意图
│   ├── 42_GTM_*                               兼容性 checker 规则
│   ├── 44_GTM_*                               工作流依赖
│   ├── 45_GTM_*                               pilot、安装、support、false-positive 模板
│   ├── 48_GTM_*                               Check Your Door 原型
│   ├── 49_GTM_*                               无线 keypad 方法参考
│   ├── 55_GTM_*                               公开兼容研究、30 类矩阵、ledger
│   ├── 56_GTM_*                               Architecture A/B、DIY 失败、交叉矩阵
│   ├── 57_GTM_*                               中文目标参数、安装问题、30 类图墙
│   ├── 58_GTM_*                               全球缺口锁型实物照片图谱
│   ├── 59_GTM_*                               全球锁型全景图
│   ├── 60_GTM_*                               新 Agent 计划、prompt、graph、package
│   ├── 99_GTM_*                               workspace cleanup manifest
│   ├── drive_imports/                         本地取得的 CAD / 视频副本
│   ├── 39_GTM_Video_Frame_Review_*/            视频抽帧与照片
│   ├── 09_GTM_CAD_*/                          CAD / 视觉参考 / renders
│   ├── intermediate/                          旧数据处理和中间结果，先不要当 source of truth
│   └── 60_GTM_GlobalLock_NewAgent_Handoff_Package_v1/
│                                               新 Agent 交接包解压目录
├── image-search/                              图片搜索下载缓存 / 内部参考
├── uploads_package/                           旧 Agent 方法论交接资料
├── exp1_baseline/                             旧方法论 / 文件规则参考
└── 其他 workspace 文件                         早期 GTM、产品、供应链和视觉资料
```

当前本地统计：

- `/home/user/exp1/`：约 359 个文件；
- `/home/user/image-search/`：约 315 个图片文件；
- 新 Agent 交接目录：约 108 个文件；
- 交接 ZIP：`60_GTM_GlobalLock_NewAgent_Handoff_Package_v1_2026-09-16.zip`。

---

## 2. 资料分层：哪些可以直接用

### A. 公益锁知识网站核心资料

```text
60_GTM_Global_Lock_PublicGood_Website_Plan_And_NewAgent_Handoff_CN_v1_2026-09-16.md
60_GTM_Global_Lock_PublicGood_Website_Source_Index_v1_2026-09-16.csv
60_GTM_Global_Lock_Knowledge_Graph_Schema_v1_2026-09-16.json
60_GTM_NewAgent_Prompt_Global_Lock_PublicGood_Website_CN_v1_2026-09-16.md
60_GTM_GlobalLock_NewAgent_Handoff_Response_CN_v1_2026-09-16.md
```

用途：

- 新 Agent 交接；
- 网站 scope；
- AI graph；
- source / rights / privacy；
- customer flow；
- engineer mode；
- 产品站导流边界。

状态：**可直接作为新 Agent 启动资料**。

### B. 全球锁型和实物照片资料

```text
59_GTM_全球锁型全景图_工程适配版_v1_2026-09-16.html
58_GTM_全球缺口锁型实物照片图谱_中文汇总_v1_2026-09-16.html
57_GTM_30类候选锁安装图_中文汇总_v1_2026-09-16.html
57_GTM_30类候选样本_中文副本_v1_2026-09-16.csv
55_GTM_Compatibility_20_30_Candidate_Matrix_v1.csv
56_GTM_Compatibility_30_Candidate_Architecture_Crosswalk_v1.csv
```

用途：

- 30 个候选；
- 12 类缺口锁族；
- 全球区域照片；
- Architecture A / B；
- adaptor 输入 / 输出；
- 图墙 landing page；
- 工程师视觉参考。

状态：

- 内容和图墙可直接参考；
- 照片版权需要逐张审核；
- 图片本身不是兼容性证据；
- 未验证 exact model 不得标为 Green。

### C. 兼容性和测试规则

```text
40_GTM_Engineering_Target_Spec_And_Claim_Ladder_v1_2026-09-16.md
40_GTM_Engineering_Target_Spec_And_Claim_Ladder_v1_2026-09-16.json
42_GTM_Compatibility_Target_And_Checker_v1_2026-09-16.md
42_GTM_Compatibility_Target_And_Checker_v1_2026-09-16.json
45_GTM_Pilot_And_Launch_Runbook_v1_2026-09-16.md
45_GTM_Pilot_And_Launch_Runbook_v1_2026-09-16.json
45_GTM_Sample_Door_Matrix_Template.csv
45_GTM_Support_Ticket_Log_Template.csv
45_GTM_Return_Replacement_Log_Template.csv
45_GTM_Compatibility_FalsePositive_Audit_Template.csv
```

用途：

- TARGET / VALIDATED / CERTIFIED 分层；
- Green / Amber / Red；
- 三次独立安装测试；
- open-door / closed-door；
- manual override；
- false-positive audit；
- 试点、support、return、replacement。

关键限制：

> torque、rotation angle、closed-door resistance、lock complete、durability、battery life 不能从普通图片或网友视频直接推导。

### D. 现有网站 / 原型 / catalogue

```text
48_GTM_Check_Your_Door_Prototype_v2.html
GTM_Catalogue_RetrofitSmartLock_QuickDecision_v0.2_2026-09-16.pdf
GTM_Catalogue_RetrofitSmartLock_DetailedCatalogue_v0.9_2026-09-16.pdf
46_GTM_QuickDecision_Catalogue_v0.2_build.py
47_GTM_DetailedCatalogue_v0.9_build.py
```

用途：

- 现有 Check Your Door 交互参考；
- 产品 decision catalogue；
- retrofit 产品导流时的兼容性表达；
- 未来迁移到公益站的客户识别流程。

状态：

- 可以参考交互；
- 不能直接把产品宣传语当作全球锁知识事实；
- 产品兼容结果仍受现有 checker 和实测规则约束。

### E. 证据、视频、CAD 和视觉资料

```text
00_EXP1-DRIVE_SourceOfTruth_Registry_CN_v1.md
39_GTM_GoogleDrive_Video_Evidence_And_Parameter_Gaps_2026-09-16.md
39_GTM_GoogleDrive_Video_Evidence_And_Parameter_Gaps_2026-09-16.json
39_GTM_Video_Frame_Review_2026-09-16/
drive_imports/
09_GTM_CAD_*/
32_GTM_CAD_Shaded_Renders_v1/
```

用途：

- 现有产品 / 样机视频；
- 外部安装参考视频；
- CAD / STEP / STL 工作副本；
- 视频抽帧；
- 产品外观和安装空间参考。

状态：

- 可用于理解现有产品和研究边界；
- 不能从视频自动推导完整工程参数；
- Drive link 已登记不代表当前 Agent 有 Drive API 实时同步能力。

### F. 旧 Agent 方法论和索引

```text
exp1_baseline/00_MTH-J00_Index_DualMethodology_FileRules_CN_v3.md
exp1_baseline/00_MTH-J01_Index_FileTree_NamingRules_CN_v3.md
uploads_package/00_MTH-J02_Audit_MethodologyCoverage_OutputIndex_NewAgentHandoff_CN_v1.md
uploads_package/00_MTH-J05_Index_PreviousAgent_Handoff_FileIndex_CN_v1.md
00_EXP1-J00_Index_MethodologyExperiment_RunLog_CN_v1.xlsx
00_EXP1-J90_Methodology_GapFix_Recommendations_CN_v1.md
00_EXP1-J90_Methodology_GapFix_Recommendations_CN_v1.xlsx
```

用途：

- 文件命名；
- 方法论覆盖；
- 旧 Agent 交接；
- source / output / NoSend 规则。

状态：**参考资料，不要覆盖当前 GlobalLockSummary schema**。

### G. 图片原始 / 缓存目录

```text
/home/user/image-search/
```

用途：

- 图片搜索下载缓存；
- 当前图墙生成素材；
- 内部视觉参考。

状态：

- 约 315 个文件；
- 不是公共版权库；
- 新 Agent 必须重新做 `rights_state`；
- 未授权不得直接发布。

推荐新 Agent 只先使用交接包中的：

```text
photo_assets/internal_reference_only/
```

---

## 3. 现有 30 类候选快速索引

| 编号范围 | 区域 | 主要锁族 |
|---|---|---|
| SG-01–SG-10 | 新加坡 / 东南亚 | 数字 Mortise、Rim、Push-pull、gate / 金属门 |
| AU-11–AU-18 | 澳大利亚 | Lockwood、Whitco、deadlatch、deadbolt、mortise、knob / lever |
| EU-19–EU-26 | 英国 / 欧洲 | Euro cylinder、thumbturn、multipoint、UK 5-lever、Euro mortise |
| US-27–US-30 | 北美 | Schlage、Kwikset、Yale、ANSI deadbolt、tubular knob / lever |

当前 30 类是第一阶段工程样本，不是全球锁全集。

---

## 4. 当前 12 类明显缺口

已在 `58_GTM_全球缺口锁型实物照片图谱...html` 中整理：

1. Scandinavian oval / round cylinder；
2. Swiss profile cylinder；
3. Japanese GOAL / MIWA / narrow-stile；
4. Indian rim / gate lock；
5. Korean metal-door / gate mechanical lock；
6. commercial panic bar / exit device；
7. sliding / patio door lock；
8. glass-door patch / clamp lock；
9. padlock / cabinet / mailbox / furniture lock；
10. non-Euro multipoint；
11. restricted / high-security cylinder；
12. complex commercial mortise / interconnected lock。

---

## 5. AI Agent 应如何选择资料

### 如果 Agent 做 taxonomy

先读：

- 59 全景图；
- 60 graph schema；
- 57 安装问题；
- 56 field relevance。

### 如果 Agent 做 landing page / 图墙

先读：

- 57 HTML；
- 58 HTML；
- 59 HTML；
- 57 中文 CSV；
- photo manifest；
- rights policy。

### 如果 Agent 做 customer photo identification

先读：

- 42 checker；
- 56 Architecture A/B；
- 45 runbook；
- 48 Check Your Door prototype；
- 60 graph schema。

### 如果 Agent 做 AI RAG / 被其他 AI 引用

先读：

- 60 plan；
- 60 graph schema；
- 60 source index；
- 40 claim ladder；
- 55 public research summary；
- 39 evidence / parameter gaps。

### 如果 Agent 做 retrofit 产品导流

先读：

- 42 checker；
- 40 target spec；
- 45 pilot runbook；
- 48 prototype；
- 38 competitive analysis；
- 57 Architecture A/B 中文总结。

---

## 6. 当前明确不存在 / 未验证的资料

新 Agent 不要假设以下资料已经存在：

- 当前 workspace 没有 Git `.git` 仓库；
- 没有独立验证 GitHub branch / PR；
- 没有 GitHub token / Gitee token；
- 没有 Cloudflare Worker URL；
- 没有 D1 / KV / R2 配置；
- 没有 Feishu / DingTalk webhook URL；
- 没有 `content/catalog/lock-families/*.json` 的 verified copy；
- 没有全部图片的公开授权；
- 没有全球 100+ lock families 的 exact model 数据；
- 没有全世界每个国家的真实安装样本；
- 没有任何自动从照片得出 Green compatibility 的证据；
- 没有全球统一的 torque、angle、durability、battery 数据。

---

## 7. 新 Agent 推荐工作顺序

```text
1. 读取本 Index Tree
2. 读取 60 Plan / Prompt / Graph Schema
3. 检查 Source Index 的 exists / readable
4. 建立 File Manifest
5. 建立 Photo Rights Audit
6. 建立 42 个 seed family records
7. 映射到仓库现有 catalog IDs（如果存在）
8. 做根图墙 landing page
9. 做 lock family detail page
10. 做 region page
11. 做 Engineer filters
12. 做 Customer identification wizard
13. 接入 Worker feedback queue
14. 加 JSON-LD / sitemap / llms.txt
15. 再接 RAG / vision classifier
16. 最后才接 product route
```

---

## 8. 最终提醒

这些资料的作用是让新 Agent 能选择和重用已有研究，不代表所有内容都可以直接上线。

特别要区分：

```text
视觉参考 ≠ exact model
公开案例 ≠ 工程测量
adaptor rotates ≠ lock complete
lock family ≠ universal compatibility
图片来源 ≠ 图片公开授权
AI top candidate ≠ 购买建议
公益知识页 ≠ 产品兼容承诺
```
