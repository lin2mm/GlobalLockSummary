from pathlib import Path
import csv, html

root = Path('/home/user/exp1')
rows = list(csv.DictReader((root/'55_GTM_Compatibility_20_30_Candidate_Matrix_v1.csv').open(encoding='utf-8-sig')))
cross = {r['candidate_id']: r for r in csv.DictReader((root/'56_GTM_Compatibility_30_Candidate_Architecture_Crosswalk_v1.csv').open(encoding='utf-8-sig'))}
cnrows = {r['样本编号']: r for r in csv.DictReader((root/'57_GTM_30类候选样本_中文副本_v1_2026-09-16.csv').open(encoding='utf-8-sig'))}

# Palette for a clean engineering schematic.
INK='#1f2937'; BLUE='#0f4c81'; CYAN='#dff3ff'; METAL='#d8dee8'; DARK='#334155'; ORANGE='#f59e0b'; GREEN='#16805b'; RED='#b42318'; DOOR='#f6efe2'; WHITE='#ffffff'; LIGHT='#f8fafc'

def esc(s): return html.escape(str(s))

def svg_base(title, subtitle, body):
    return f'''<svg class="diagram" viewBox="0 0 900 390" role="img" aria-label="{esc(title)}安装示意图">
      <rect x="0" y="0" width="900" height="390" rx="14" fill="#ffffff" stroke="#cbd5e1"/>
      <text x="30" y="34" font-family="Arial,Microsoft YaHei,sans-serif" font-size="18" font-weight="700" fill="{INK}">{esc(title)}</text>
      <text x="30" y="58" font-family="Arial,Microsoft YaHei,sans-serif" font-size="12" fill="#64748b">{esc(subtitle)}</text>
      {body}
    </svg>'''

def label(x,y,text,size=14,color=INK,weight='400',anchor='start'):
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,Microsoft YaHei,sans-serif" font-size="{size}" font-weight="{weight}" fill="{color}">{esc(text)}</text>'

def arrow(x1,y1,x2,y2,color=ORANGE,dashed=False):
    dash=' stroke-dasharray="7 5"' if dashed else ''
    return f'<defs><marker id="m{abs(x1)+abs(y1)+abs(x2)+abs(y2)}" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L6,3 z" fill="{color}"/></marker></defs><line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="3" marker-end="url(#m{abs(x1)+abs(y1)+abs(x2)+abs(y2)})"{dash}/>'

def door_side(x=120, y=115, h=220, w=26):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><line x1="{x+w/2}" y1="{y+10}" x2="{x+w/2}" y2="{y+h-10}" stroke="#c4b5a5"/>'

def lock_case(x,y,w=125,h=65, title='lock case'):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/><rect x="{x+w-8}" y="{y+17}" width="35" height="12" rx="4" fill="{DARK}"/><rect x="{x+w-8}" y="{y+39}" width="35" height="12" rx="4" fill="{DARK}"/>{label(x+8,y+26,title,11,DARK,"700")}'

def rotary(x,y,r=24,kind='thumbturn'):
    extra = f'<circle cx="{x}" cy="{y}" r="{r}" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><line x1="{x-r+6}" y1="{y}" x2="{x+r-6}" y2="{y}" stroke="{BLUE}" stroke-width="5" stroke-linecap="round"/>'
    return extra + label(x,y+r+19,kind,12,BLUE,'700','middle')

def diagram_for(cid, cn, en):
    # Generic door/lock installation schematics. These deliberately show the mechanical interface, not product CAD.
    if cid in {'SG-01','SG-02','SG-07','SG-08','SG-09','SG-10'}:
        body = door_side()+lock_case(147,187,118,72,'mortise case')
        body += f'<rect x="280" y="152" width="125" height="142" rx="18" fill="{BLUE}"/><rect x="300" y="173" width="85" height="50" rx="8" fill="#e7f3fb"/><circle cx="342" cy="249" r="19" fill="#f4b942"/><rect x="338" y="274" width="9" height="32" fill="#f4b942"/>'
        body += label(342,328,'外侧数字面板 / exterior',12,BLUE,'700','middle')
        body += f'<rect x="520" y="165" width="145" height="110" rx="18" fill="{METAL}" stroke="{DARK}" stroke-width="2"/><circle cx="592" cy="220" r="23" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><line x1="573" y1="220" x2="611" y2="220" stroke="{BLUE}" stroke-width="5"/>'
        body += label(592,305,'内侧电机 / inside motor',12,BLUE,'700','middle')
        body += arrow(405,222,515,222,ORANGE)
        body += label(465,205,'通过锁体联动',12,ORANGE,'700','middle')
    elif cid in {'SG-03','SG-05','SG-06'}:
        body = f'<rect x="100" y="110" width="180" height="225" rx="5" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="280" y="110" width="22" height="225" fill="#eadfcd" stroke="{DARK}"/>'
        body += f'<rect x="302" y="165" width="145" height="105" rx="10" fill="{METAL}" stroke="{DARK}" stroke-width="2"/><circle cx="375" cy="215" r="25" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><line x1="354" y1="215" x2="396" y2="215" stroke="{BLUE}" stroke-width="5"/>'
        body += label(375,297,'门面安装的 Rim case',12,DARK,'700','middle')
        body += f'<rect x="458" y="183" width="100" height="65" rx="10" fill="#e7f3fb" stroke="{BLUE}" stroke-width="3"/><circle cx="508" cy="215" r="15" fill="{BLUE}"/>'
        body += label(508,277,'可能的内侧旋钮',12,BLUE,'700','middle')
        body += arrow(447,215,495,215,ORANGE)
        body += label(474,198,'先确认是否联动',11,ORANGE,'700','middle')
        body += label(720,160,'Rim / surface',14,BLUE,'700','middle')
        body += label(720,183,'外侧钥匙、内侧旋钮、锁舌',12,DARK,'400','middle')
        body += label(720,202,'必须分别观察',12,RED,'700','middle')
    elif cid in {'SG-04','SG-06'}:
        body = door_side()+lock_case(147,187,118,72,'mortise case')
        body += f'<rect x="310" y="120" width="100" height="210" rx="18" fill="{BLUE}"/><rect x="335" y="150" width="50" height="55" rx="8" fill="#e7f3fb"/><rect x="285" y="210" width="150" height="15" rx="7" fill="#f4b942"/>'
        body += arrow(360,95,360,145,ORANGE)
        body += arrow(360,255,360,305,ORANGE)
        body += label(360,350,'推拉把手 + Mortise case',12,BLUE,'700','middle')
        body += label(580,150,'必须验证：',14,DARK,'700')
        body += label(580,178,'把手动作、锁舌回缩、deadbolt 状态',12,DARK)
        body += label(580,202,'不是只看面板或电机是否移动',12,RED,'700')
    elif cid in {'AU-11','AU-12','AU-17'}:
        body = f'<rect x="100" y="110" width="210" height="225" rx="5" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="310" y="110" width="24" height="225" fill="#eadfcd" stroke="{DARK}"/>'
        body += lock_case(334,180,120,75,'deadlatch')+rotary(530,217,26,'inside knob')
        body += arrow(455,217,500,217,ORANGE)
        body += f'<rect x="454" y="193" width="28" height="48" rx="3" fill="{DARK}"/>'
        body += label(690,160,'AU deadlatch',14,BLUE,'700','middle')
        body += label(690,184,'检查 safety release 与锁舌',12,DARK,'400','middle')
        body += label(690,207,'是否同时改变',12,DARK,'400','middle')
        body += label(690,230,'lock state',12,RED,'700','middle')
    elif cid == 'AU-13':
        body = door_side()+lock_case(147,180,120,78,'deadlock')+rotary(470,219,28,'turnknob / key input')
        body += arrow(270,219,425,219,ORANGE)
        body += label(345,201,'直接旋转输入',12,ORANGE,'700','middle')
        body += label(700,160,'重点：方向、角度、转数',14,BLUE,'700','middle')
        body += label(700,185,'开门 / 关门阻力不同',12,DARK,'400','middle')
        body += label(700,210,'不能只按外观判定',12,RED,'700','middle')
    elif cid in {'AU-14','AU-15','EU-24','EU-25','EU-26'}:
        body = f'<rect x="100" y="105" width="42" height="240" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="142" y="145" width="178" height="160" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/>'
        body += f'<rect x="195" y="178" width="75" height="48" rx="4" fill="{DARK}"/><rect x="270" y="188" width="45" height="12" fill="{DARK}"/><rect x="270" y="210" width="45" height="12" fill="{DARK}"/>'
        body += f'<circle cx="380" cy="180" r="22" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><line x1="363" y1="180" x2="397" y2="180" stroke="{BLUE}" stroke-width="5"/>'
        body += f'<rect x="430" y="165" width="125" height="105" rx="12" fill="#e7f3fb" stroke="{BLUE}" stroke-width="2"/>'
        body += label(492,225,'把手 / 方杆',12,BLUE,'700','middle')+arrow(405,180,430,180,ORANGE)
        body += label(710,155,'Mortise case',14,BLUE,'700','middle')
        body += label(710,179,'deadbolt、latch、把手可能联动',12,DARK,'400','middle')
        body += label(710,203,'必须分别记录输出',12,RED,'700','middle')
    elif cid in {'AU-16'}:
        body = f'<rect x="100" y="105" width="42" height="240" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="142" y="165" width="155" height="115" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/>'
        body += f'<circle cx="205" cy="222" r="35" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><circle cx="205" cy="222" r="8" fill="{BLUE}"/><rect x="297" y="205" width="75" height="34" fill="{DARK}"/>'
        body += f'<circle cx="480" cy="222" r="35" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><circle cx="480" cy="222" r="8" fill="{BLUE}"/>'
        body += label(205,290,'外侧 key',12,DARK,'700','middle')+label(480,290,'内侧 key',12,DARK,'700','middle')
        body += label(700,155,'双Cylinder Deadbolt',14,BLUE,'700','middle')
        body += label(700,180,'必须确认 emergency / manual override',12,RED,'700','middle')
        body += label(700,204,'和两侧钥匙路径',12,DARK,'400','middle')
    elif cid == 'AU-18' or cid == 'US-30':
        body = door_side()+lock_case(147,185,118,72,'tubular latch')
        body += f'<circle cx="440" cy="221" r="40" fill="{METAL}" stroke="{DARK}" stroke-width="3"/><circle cx="440" cy="221" r="16" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/>'
        body += label(440,285,'knob',12,BLUE,'700','middle')+arrow(270,221,400,221,ORANGE)
        body += label(700,160,'Knob / lever',14,BLUE,'700','middle')
        body += label(700,184,'可能只是回缩 latch',12,DARK,'400','middle')
        body += label(700,207,'不等于 unlock',12,RED,'700','middle')
    elif cid in {'EU-19','EU-20'}:
        body = f'<rect x="100" y="105" width="42" height="240" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="142" y="160" width="380" height="120" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/>'
        body += f'<path d="M290 160 v120" stroke="{BLUE}" stroke-width="5"/><rect x="285" y="202" width="12" height="36" fill="{ORANGE}"/><circle cx="350" cy="220" r="23" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><path d="M350 197 A23 23 0 0 1 373 220" fill="none" stroke="{ORANGE}" stroke-width="4"/>'
        body += label(350,275,'cam / cylinder',12,BLUE,'700','middle')+arrow(170,220,315,220,ORANGE)
        body += label(680,160,'Euro double cylinder',14,BLUE,'700','middle')
        body += label(680,184,'记录 profile、A/B、cam、转数',12,DARK,'400','middle')
        body += label(680,208,'并观察锁体输出',12,RED,'700','middle')
    elif cid in {'EU-21','EU-22'}:
        body = f'<rect x="100" y="105" width="42" height="240" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="142" y="160" width="310" height="120" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/><path d="M285 160 v120" stroke="{BLUE}" stroke-width="5"/><rect x="280" y="202" width="12" height="36" fill="{ORANGE}"/>'
        body += rotary(535,220,29,'thumbturn')+arrow(452,220,500,220,ORANGE)
        body += label(700,160,'Euro thumbturn',14,BLUE,'700','middle')
        body += label(700,184,'先确认 thumbturn 可拆、直径和啮合',12,DARK,'400','middle')
        body += label(700,208,'再测 defender / 外露 / 关门阻力',12,RED,'700','middle')
    elif cid == 'EU-23':
        body = f'<rect x="100" y="95" width="42" height="250" fill="{DOOR}" stroke="{DARK}" stroke-width="2"/><rect x="142" y="95" width="28" height="250" fill="#eadfcd" stroke="{DARK}"/><rect x="170" y="145" width="100" height="145" rx="8" fill="{METAL}" stroke="{DARK}" stroke-width="2"/><rect x="220" y="160" width="22" height="55" fill="{DARK}"/><rect x="220" y="220" width="22" height="55" fill="{DARK}"/>'
        body += f'<circle cx="360" cy="215" r="25" fill="{CYAN}" stroke="{BLUE}" stroke-width="3"/><line x1="360" y1="190" x2="360" y2="240" stroke="{BLUE}" stroke-width="5"/>'
        body += arrow(360,178,360,125,ORANGE)+arrow(360,252,360,305,ORANGE)
        body += label(360,335,'先抬把手，再转 cylinder',12,RED,'700','middle')
        body += label(700,160,'Lift-to-lock multipoint',14,BLUE,'700','middle')
        body += label(700,184,'旋转输入 ≠ 完成多点锁定',12,RED,'700','middle')
        body += label(700,208,'必须记录全部 locking points',12,DARK,'400','middle')
    else:
        # generic ANSI deadbolt / fallback
        body = door_side()+lock_case(147,185,118,72,'deadbolt case')+rotary(465,221,28,'thumbturn')
        body += arrow(270,221,420,221,ORANGE)
        body += label(700,160,'单一旋转输入',14,BLUE,'700','middle')
        body += label(700,184,'开门 / 关门 / 手动旁路',12,DARK,'400','middle')
        body += label(700,208,'均需独立验证',12,RED,'700','middle')
    return svg_base(cn, f'{cid} · {en} · 代表性安装示意（不按比例）', body)

# One real-world image/reference per candidate. The image is embedded into the final HTML so the report remains a single file.
# Type is deliberately explicit: exact model door photo, family/variant door photo, or product/installation reference.
real_cases = {
 'SG-01': ('yale-ydm4109-installed-on-door-interior--1.jpg','https://sharpi.in/product/yale-ydm4109a-rl-smart-digital-intelligent-bio-metric-door-lock-free-installation-by-yale-buy-online-india/','Exact model / installation-service product page'),
 'SG-02': ('yale-ydm7116-installed-on-door-installat-2.png','https://cloudswoodmall.com/yale-ydm7116','Exact model / door-mounted product reference'),
 'SG-03': ('yale-ydr3110a-rim-lock-installed-on-door-2.png','https://l3homeation.com.sg/digital-lock-yale-ydr3110a.html','Exact model / rim-lock product reference'),
 'SG-04': ('samsung-shp-dp728-installed-on-door-inst-1.webp','https://www.lazada.sg/products/free-installation-samsung-shp-dp728-smart-digital-lock-i263599294.html','Exact model / installation-service listing'),
 'SG-05': ('samsung-shp-h20-installed-on-door-photo-3.webp','https://picclick.com.au/Samsung-SHP-H20-Smart-Digital-Door-Lock-2-236224185444.html','Exact model / no-drill door-lock reference'),
 'SG-06': ('zigbang-shp-p52-installed-on-door-photo-1.jpg','https://andigitallock.com/products/zigbang-shp-p52-digital-door-lock-shp-a21-digital-gate-lock','Exact model / door-lock product reference'),
 'SG-07': ('aqara-a100-installed-on-door-photo-smart-1.png','https://www.aqara.com/en/news/aqara-introduces-smart-door-lock-a100-zigbee-with-apple-home-key-support/','Exact model / manufacturer product reference'),
 'SG-08': ('gateman-sp122-installed-on-door-photo-1.jpg','https://interlock.com.sg/products/gateman-sp122','Exact model / Singapore product reference'),
 'SG-09': ('kaadas-k9-5w-installed-on-door-photo-2.webp','https://kaadassg.com/product/kaadas-k9-5w/','Exact model / product reference'),
 'SG-10': ('philips-easykey-alpha-installed-on-door--1.jpg','https://sheildify.com/product/philips-easykey-alpha-door-lock-with-push-pull-black/','Exact model / push-pull door-lock reference'),
 'AU-11': ('lockwood-001-deadlatch-installed-on-door-1.jpg','https://saslocksmiths.com/products/lockwood-001-deadlatch-evb','Exact model / deadlatch product reference'),
 'AU-12': ('lockwood-002-digital-deadlatch-installed-1.jpg','https://www.handles4homes.co.uk/lockwood-002-digital-combination-deadlatch-open-in-satin-chrome-p32346','Exact model / installed-open-in reference'),
 'AU-13': ('lockwood-355-installed-door-photo-deadlo-1.jpg','https://thedoorstore.com.au/product/lockwood-355-double-cylinder-deadlock-bright-chrome-double-cylinder/','Exact model / product reference; door installation not fully visible'),
 'AU-14': ('lockwood-selector-3770-installed-on-door-1.jpg','https://thelockshop.com.au/products/lockwood-selector-3772-universal-mortice-lock','Selector family / mortice installation reference'),
 'AU-15': ('lockwood-4770-4772-mortice-lock-installe-1.jpg','https://accesshardware.com.au/lockwood-selector-4772-primary-mortice-lock-89mm-extended-backset-satin-stainless-steel','Exact extended-backset family / product reference'),
 'AU-16': ('whitco-double-cylinder-deadbolt-installe-1.jpg','https://www.primehardware.com.au/products/whitco-w7204055ka','Exact family / double-cylinder deadbolt reference'),
 'AU-17': ('whitco-double-cylinder-deadlatch-install-1.png','https://safeandsoundlocksmiths.com.au/products/whitco-w75-double-cylinder-deadlatch-with-safety-release-w750605','Exact family / deadlatch product reference'),
 'AU-18': ('whitco-key-in-knob-lever-installed-on-do-1.png','https://doorcorner.com/blogs/articles-and-advice/door-knobs-and-door-lever-functions','Knob/lever family / door-hardware reference'),
 'EU-19': ('aqara-u200-installed-on-euro-cylinder-do-1.jpg','https://www.reddit.com/r/Aqara/comments/1lva1l3/safest_and_most_reliable_euro_cylinder/','Euro-cylinder family / retrofit installed case'),
 'EU-20': ('aqara-u200-installed-on-euro-cylinder-do-2.jpg','https://www.reddit.com/r/Aqara/comments/1lva1l3/safest_and_most_reliable_euro_cylinder/','Euro-cylinder family / retrofit installed case'),
 'EU-21': ('euro-cylinder-thumbturn-installed-in-doo-2.jpg','https://danddhardware.com/Euro-Lock-Cylinder-Thumbturn-DDCT002-pd42154644.html','Thumbturn Euro family / installation reference'),
 'EU-22': ('euro-cylinder-40-50-asymmetric-thumbturn-4.jpg','https://www.lockstation.co.uk/euro-thumbturn-cylinders-locks','Asymmetric Euro family / product reference; not exact door photo'),
 'EU-23': ('euro-multipoint-lock-installed-on-door-h-1.webp','https://installixwnd.ca/blog/smart-locks-multipoint-doors','Multipoint family / installed cutaway case'),
 'EU-24': ('uk-5-lever-mortice-deadlock-installed-in-2.webp','https://www.mbdiy.co.uk/blog/comparisons/5-lever-mortice-or-a-upvc-multipoint-door-lock/','UK mortice family / installation reference'),
 'EU-25': ('uk-sashlock-5-lever-installed-door-photo-1.png','https://www.barnsleylock.co.uk/asec-vital--bs--5-lever-mortice-sashlock-7722-p.asp','UK sashlock family / product reference'),
 'EU-26': ('union-chubb-3c10-euro-mortice-lock-insta-1.webp','https://picclick.co.uk/Chubb-3C10%C2%A0mortice-lock%C2%A0with-5-pin-euro-cylinder-with-223240296108.html','Exact lock family / Euro mortice reference'),
 'US-27': ('schlage-b60-installed-on-door-photo-inte-2.jpg','https://www.homedepot.com/p/Schlage-B81-Series-Aged-Bronze-One-Sided-Deadbolt-Thumbturn-with-Exterior-Plate-Certified-Highest-for-Security-and-Durability-B81-716/300978065','ANSI deadbolt family / door-mounted reference'),
 'US-28': ('kwikset-660-installed-on-door-photo-dead-3.webp','https://www.harborcitysupply.com/kwikset-security-660-series-keyed-deadbolt/','Exact model / interior door-mounted reference'),
 'US-29': ('yale-assure-lock-2-installed-on-door-pho-1.jpg','https://www.cnet.com/home/security/best-smart-locks/','Exact model / installed-on-door review photo'),
 'US-30': ('tubular-entrance-knob-lever-installed-on-1.jpg','https://www.houseofantiquehardware.com/shop-by-type/antique-door-hardware/locksets/front-door-hardware','Tubular knob/lever family / door-hardware reference'),
}

def embedded_photo(case):
    from PIL import Image
    import io, base64, mimetypes
    filename, url, typ = case
    path = Path('/home/user/image-search') / filename
    if not path.exists():
        return '<div class="photo-missing">实物案例图未找到</div>'
    try:
        im = Image.open(path).convert('RGB')
        im.thumbnail((920, 620))
        bio = io.BytesIO(); im.save(bio, format='JPEG', quality=78, optimize=True)
        data = base64.b64encode(bio.getvalue()).decode('ascii')
        return f'''<div class="realphoto"><img src="data:image/jpeg;base64,{data}" alt="实物安装案例参考"><div class="photocaption"><b>实物 / 门上案例参考：</b>{esc(typ)}<br><a href="{esc(url)}">打开图片来源页面</a></div></div>'''
    except Exception as e:
        return f'<div class="photo-missing">实物案例图读取失败：{esc(e)}</div>'

coverage = [
 ('Euro profile / Euro cylinder','已覆盖','EU-19–EU-23、EU-26','30/30、35/35、thumbturn、multipoint、Euro mortise；仍需增加更多 cam / A-B 组合。'),
 ('Multipoint / lift-to-lock','已覆盖但只有边界样本','EU-23','覆盖了最重要的失败边界，但不能代表所有 gear / handle sequence。'),
 ('UK 5-lever mortice','已覆盖','EU-24–EU-25','覆盖 deadlock 和 sashlock；不代表所有英国品牌和 case。'),
 ('Australian deadlatch / deadbolt / mortise','已覆盖','AU-11–AU-17','覆盖 Lockwood、Whitco 的主要 retrofit 相关族。'),
 ('Knob / lever / tubular','已覆盖','AU-18、US-30','只覆盖基础入口锁；仍需更多 spindle、spring 和 interconnected 变体。'),
 ('US ANSI single-cylinder deadbolt','已覆盖','US-27–US-29','覆盖 Schlage / Kwikset / Yale 代表族；应继续增加不同 tailpiece 与 electronic variants。'),
 ('Rim / surface-mounted','部分覆盖','SG-03、SG-05、SG-06','当前代表多为数字 Rim / 推拉产品；需另采购机械 nightlatch / Jimmy-Proof 样本。'),
 ('Singapore / Korean-style digital mortise','已覆盖为整锁边界样本','SG-01–SG-10','用于判断现有外壳 retrofit 是否不自然，不应直接当作机械兼容 Green。'),
 ('Scandinavian oval / round cylinder','未覆盖','—','应增加独立 cylinder profile 和 adapter 样本。'),
 ('Swiss profile / restricted profiles','未覆盖','—','应增加 profile、cam、A/B 和 defender 记录。'),
 ('Japanese narrow-stile / GOAL / MIWA','未覆盖','—','应增加窄门框、锁体深度和偏心 cylinder 样本。'),
 ('Indian rim lock / gate lock','未覆盖','—','应增加 rim case、旋钮联动和门闸安装样本。'),
 ('Commercial panic / exit device','未覆盖','—','不能用普通 deadbolt / mortise 结论替代。'),
 ('Sliding / patio / glass-door lock','未覆盖','—','应作为不同机械运动方向和固定方式的独立族。'),
 ('Padlock / cabinet / mailbox / furniture lock','未覆盖','—','不属于当前门内 retrofit 的优先范围。'),
]

cards=[]
for r in rows:
    cid=r['candidate_id']; cn=cnrows[cid]; cr=cross[cid]
    diagram=diagram_for(cid, cn['中文锁类'], r['representative_lock_or_profile'])
    architecture = f"A：{cn['Architecture A现有锁驱动']}；B：{cn['Architecture B配套Cylinder']}"
    source = r['public_source_url']
    case = real_cases.get(cid)
    photo_html = embedded_photo(case) if case else '<div class="photo-missing">暂无实物案例图</div>'
    cards.append(f'''<section class="card">
      <div class="cardhead"><span class="id">{esc(cid)}</span><h3>{esc(cn['中文锁类'])}：{esc(r['representative_lock_or_profile'])}</h3><span class="badge">{esc(cn['初始旋转宣传级别'])}</span></div>
      <div class="diagramwrap">{diagram}</div>
      {photo_html}
      <div class="grid"><div><b>安装形态</b><br>{esc(r['mechanical_form'])}</div><div><b>Architecture A / B</b><br>{esc(architecture)}</div><div><b>主要安装关注点</b><br>{esc(cn['主要安装关注点'])}</div><div><b>主要失败风险</b><br>{esc(cn['主要失败风险'])}</div></div>
      <p class="check"><b>最低验证：</b>{esc(cn['最低实物验证'])}</p>
      <p class="source"><b>类别 / 型号参考：</b><a href="{esc(source)}">{esc(source)}</a></p>
      <p class="note">图中为统一工程讨论示意图，不是该品牌的 CAD 或安装尺寸图；实物采购后必须替换或补充 exact model manual / field photo。</p>
    </section>''')

coverage_html=''.join(f'<tr><td>{esc(a)}</td><td class="status">{esc(b)}</td><td>{esc(c)}</td><td>{esc(d)}</td></tr>' for a,b,c,d in coverage)
html_doc=f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>30类候选锁安装图中文汇总</title>
<style>
body{{font-family:Arial,"Microsoft YaHei",sans-serif;color:#1f2937;background:#eef2f7;margin:0;line-height:1.5}}
main{{max-width:1220px;margin:0 auto;padding:30px 28px 60px;background:#fff;min-height:100vh}}
h1{{font-size:30px;margin:0 0 8px;color:#102a43}}h2{{margin-top:34px;border-left:5px solid #0f4c81;padding-left:12px;color:#123b5d}}h3{{font-size:18px;margin:0;display:inline-block;color:#102a43}}
.meta{{color:#64748b;margin-bottom:22px}}.warning{{background:#fff7ed;border:1px solid #fdba74;padding:14px 18px;border-radius:10px;margin:18px 0}}
.legend{{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0 24px}}.legend span,.badge{{border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700}}.r0{{background:#fee2e2;color:#991b1b}}.r1{{background:#dcfce7;color:#166534}}.r2{{background:#fef3c7;color:#92400e}}.badge{{background:#eef2ff;color:#3730a3;float:right}}
.cards{{display:grid;grid-template-columns:1fr 1fr;gap:22px}}.card{{border:1px solid #d8e0ea;border-radius:14px;padding:15px;background:#fff;box-shadow:0 2px 8px rgba(15,76,129,.06);break-inside:avoid}}.cardhead{{margin-bottom:10px}}.id{{display:inline-block;color:#fff;background:#0f4c81;border-radius:5px;padding:3px 7px;font-size:12px;font-weight:700;margin-right:8px;vertical-align:3px}}.diagram{{width:100%;height:auto;display:block}}
.realphoto{{margin-top:12px;border:1px solid #cbd5e1;border-radius:10px;padding:8px;background:#f8fafc}}.realphoto img{{display:block;width:100%;max-height:360px;object-fit:contain;background:#fff;border-radius:7px}}.photocaption{{font-size:11px;color:#64748b;padding:6px 2px 0;overflow-wrap:anywhere}}.photo-missing{{margin-top:12px;border:1px dashed #94a3b8;border-radius:10px;padding:18px;text-align:center;color:#64748b;background:#f8fafc}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:10px;font-size:12px}}.grid>div{{background:#f8fafc;border-radius:8px;padding:8px}}.grid b{{color:#0f4c81}}.check{{background:#eff6ff;border-left:3px solid #0f4c81;padding:8px 10px;font-size:13px;margin:10px 0}}.source,.note{{font-size:11px;color:#64748b;overflow-wrap:anywhere}}a{{color:#0f4c81}}.note{{font-style:italic}}
table{{width:100%;border-collapse:collapse;font-size:13px;margin-top:12px}}th,td{{border:1px solid #d8e0ea;padding:8px;vertical-align:top}}th{{background:#eaf2f8;color:#123b5d;text-align:left}}.status{{font-weight:700;white-space:nowrap}}.coverage-note{{background:#f8fafc;border:1px solid #d8e0ea;border-radius:10px;padding:15px;margin:12px 0}}
@media(max-width:900px){{.cards{{grid-template-columns:1fr}}main{{padding:20px 14px}}}}
</style></head><body><main>
<h1>30 类候选锁样本：安装图与中文工程说明</h1>
<p class="meta">GTM Compatibility · 中文工程副本 · 2026-09-16 · 版本 v1</p>
<div class="warning"><b>重要说明：</b>每个候选现在同时包含两部分：①统一风格的代表性安装示意图（engineering discussion schematic）；②一张来自公开产品页、安装服务页、评测页或用户案例的实物 / 门上案例参考图。实物图的 exactness 已在每张卡标注：有些是 exact model，有些是 lock family / variant reference，少数是产品实物而不是完整门上照片。任何实物图都不等同于兼容证明；实物验证仍须使用 exact model、exact variant、door open / closed 和 3 次独立测试。图片仅用于内部工程讨论，未做外部营销版权清理，不应直接放入销售目录或广告。</div>
<div class="legend"><span class="r1">R1：优先测试</span><span class="r2">R2：实测后再宣传</span><span class="r0">R0 / R3：当前不能宣称完整 lock / unlock</span></div>
<h2>如何阅读这些图</h2>
<ul><li>蓝色模块通常表示锁体、内侧电机或内侧控制件；橙色箭头表示候选旋转 / 联动路径。</li><li>图中的“lock case / bolt / latch / cam / handle lift”是需要在实物测试中观察的输出，不是从外观推断。</li><li>Architecture A 关注抓取客户原有机械输入；Architecture B 关注 supplied cylinder 与客户 lock case 的组合。</li><li>R0 不是“坏锁”结论，而是说明当前没有足够证据把 adaptor 旋转宣传为完整锁定 / 解锁。</li></ul>
<h2>全球大类覆盖判断</h2>
<div class="coverage-note"><b>结论：不是全球所有机械锁的完整清单。</b>这 30 个候选是围绕新加坡、澳大利亚、欧洲 / 英国、北美 retrofit 需求建立的优先测试矩阵，已覆盖多类高价值门锁接口，但仍缺少 Scandinavian、Swiss、Japanese narrow-stile、Indian rim、commercial panic、sliding / patio、glass-door、padlock 等独立锁族。10 个 SG 样本中有若干是数字整锁，它们用于做 retrofit 边界判断，不应被视为已覆盖对应地区全部机械锁。</div>
<table><thead><tr><th>全球锁族 / lock family</th><th>本矩阵状态</th><th>样本</th><th>中文判断</th></tr></thead><tbody>{coverage_html}</tbody></table>
<h2>30 个候选样本：安装示意 + 实物 / 门上案例参考</h2>
<div class="cards">{''.join(cards)}</div>
<h2>最终工程结论</h2>
<div class="warning"><b>不能只看旋钮或 adaptor 是否转动。</b>只有确认 deadbolt、latch、mortise、cam 或 multipoint locking points 的实际输出，完成 door open / door closed 测试，并保留安全的 manual override，才能进入 lock / unlock claim 讨论。当前 30 个候选仍没有任何一个自动获得 Green。</div>
<p class="meta">相关中文版文件：57_GTM_工程目标参数与测试判定_中文副本_v1_2026-09-16.md；57_GTM_锁安装问题与适配架构总结_中文副本_v1_2026-09-16.md；57_GTM_30类候选样本_中文副本_v1_2026-09-16.csv。</p>
</main></body></html>'''
(root/'57_GTM_30类候选锁安装图_中文汇总_v1_2026-09-16.html').write_text(html_doc,encoding='utf-8')
print('wrote', root/'57_GTM_30类候选锁安装图_中文汇总_v1_2026-09-16.html', len(cards), 'cards')
