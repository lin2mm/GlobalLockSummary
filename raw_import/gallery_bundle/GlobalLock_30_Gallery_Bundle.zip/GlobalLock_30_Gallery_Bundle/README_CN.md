# GlobalLock 30 Gallery Bundle

- `57_GTM_30类候选锁安装图_中文汇总_v1_2026-09-16.html`: 原始完整 HTML，保留作为结构和样式参考。
- `images/`: 30 张独立实物 / 产品 / 安装参考图，打包时未重新压缩。
- `diagrams/`: 从原始 HTML 提取的 30 张 inline schematic SVG。
- `gallery-manifest.json`: 30 类结构化映射。
- `gallery-source-manifest.csv`: 来源、rights state、SHA-256。
- `source/`: 现有索引、graph、prompt、CSV 和生成脚本。

重要：照片的公开再发布权限尚未逐张确认，manifest 标记为 internal reference only。新 Agent 发布前必须做 rights audit。图片或图墙不等于 exact-model compatibility 或 Green 证明。
